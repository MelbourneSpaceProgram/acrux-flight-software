tests="
duplicate_param
ok
"
