tests="
array
constant_1
constant_2
enum
enum_constant
struct
"
