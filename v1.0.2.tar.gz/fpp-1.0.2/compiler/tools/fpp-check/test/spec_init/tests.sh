tests="
duplicate_phase
ok
undef_phase
"
