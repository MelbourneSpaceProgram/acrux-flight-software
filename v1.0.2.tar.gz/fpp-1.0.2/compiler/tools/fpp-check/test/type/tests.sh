tests="
string_size_invalid
string_size_not_numeric
uses_ok
"

