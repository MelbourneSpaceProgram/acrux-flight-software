tests="
duplicate_instance
ok
undef_instance
"
