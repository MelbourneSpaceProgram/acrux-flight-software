tests="
enum_kwd_name
enum_missing_name
enum_ok
"
