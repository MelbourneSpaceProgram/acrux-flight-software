tests="
array_enum
array_qual_id
array_string
"
