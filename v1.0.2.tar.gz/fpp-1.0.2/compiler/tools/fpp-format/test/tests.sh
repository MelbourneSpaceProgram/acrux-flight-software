tests="
component
escaped_strings
include
kwd_names
no_include
"
