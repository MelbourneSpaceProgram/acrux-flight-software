package fpp.compiler.util

/** The compiler version */
object Version {

  val v = "[unknown version]"

}
