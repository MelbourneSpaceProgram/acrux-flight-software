package fpp.compiler.util

/** An FPP compilation tool */
final case class Tool(name: String) {
  override def toString = name
}
